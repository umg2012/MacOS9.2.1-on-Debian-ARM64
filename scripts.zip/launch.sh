#!/bin/bash
# install-macos9.sh
# Automates Mac OS 9.2.1 installation in QEMU PPC
# --- Banner ---
clear
echo "======================================="
echo "|                                     |"
echo "|    ██    ██ ███    ███  ██████      |"
echo "|    ██    ██ ████  ████ ██           |"
echo "|    ██    ██ ██ ████ ██ ██  ████     |"
echo "|    ██    ██ ██  ██  ██ ██    ██     |"
echo "|     ██████  ██      ██  ██████      |"
echo "|                                     |"
echo "======================================="
echo "|          U M G   Launcher           |"
echo "======================================="
# --- Config ---
MEM=256
HDD_NAME="ppc9-hdd.img"      # HDD
HDD_SIZE="4G"                # HDD capacity
ISO_NAME="isos/macos9.2.1.iso"    # installer iso
FORMAT="qcow2"               # hdd format
CHECK_FILE=".installed"      # renamed marker file
# --- Step 1: Check for HDD ---
if [ ! -f "$HDD_NAME" ]; then
  echo "No HDD found. Creating $HDD_NAME..."
  qemu-img create -f $FORMAT $HDD_NAME $HDD_SIZE
else
  echo "HDD already exists: $HDD_NAME"
fi
# --- Step 2: Check if Mac OS 9.2.1 is installed ---
if [ ! -f "$CHECK_FILE" ]; then
  echo "Launching installer..."
  qemu-system-ppc \
    -M mac99 \
    -cpu G4 \
    -m $MEM \
    -hda $HDD_NAME \
    -cdrom $ISO_NAME \
    -boot d \
    -device usb-kbd \
    -device usb-mouse
  # After QEMU exits, assume install is complete
  echo "Marking installation complete..."
  touch $CHECK_FILE
else
  echo "Mac OS 9.2.1 already installed. Booting from HDD..."
  qemu-system-ppc \
    -M mac99 \
    -cpu G4 \
    -m $MEM \
    -hda $HDD_NAME \
    -boot c \
    -device usb-kbd \
    -device usb-mouse
fi
