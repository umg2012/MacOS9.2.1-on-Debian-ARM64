#!/bin/bash
# install-qemu.sh
# Installs QEMU PPC packages on Raspberry Pi (Debian/Ubuntu based)
# Prints "UMG" banner before running, checks internet, then installs

set -e

# --- Step 0: Print banner ---
clear
echo "======================================="
echo "|                                     |"
echo "|    ██    ██ ███    ███  ██████      |"
echo "|    ██    ██ ████  ████ ██           |"
echo "|    ██    ██ ██ ████ ██ ██  ████     |"
echo "|    ██    ██ ██  ██  ██ ██    ██     |"
echo "|     ██████  ██      ██  ██████      |"
echo "|                                     |"
echo "======================================="
echo "|         U M G   Installer           |"
echo "======================================="

# --- Step 1: Check internet connection ---
echo "Checking internet connection..."
if ping -c 1 archive.ubuntu.com >/dev/null 2>&1; then
    echo "Internet connection OK."
else
    echo "Error: No internet connection detected. Please connect and rerun this script."
    exit 1
fi

# --- Step 2: Update package lists ---
echo "Updating package lists..."
sudo apt-get update -y

# --- Step 3: Install QEMU packages ---
echo "Installing QEMU system packages..."
sudo apt-get install -y qemu-system qemu-system-ppc qemu-utils

# --- Step 4: Verify installation ---
echo "Verifying QEMU installation..."
if command -v qemu-system-ppc >/dev/null 2>&1; then
    echo "QEMU PPC installed successfully!"
    qemu-system-ppc --version
else
    echo "Error: QEMU PPC not found after installation."
    exit 1
fi

echo "=== Installation complete ==="
echo "You can now run ./launch.sh to start Mac OS 9.2.1"

